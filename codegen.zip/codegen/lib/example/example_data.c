/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * example_data.c
 *
 * Code generation for function 'example_data'
 *
 */

/* Include files */
#include "example_data.h"

/* End of code generation (example_data.c) */
