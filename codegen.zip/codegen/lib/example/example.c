/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * example.c
 *
 * Code generation for function 'example'
 *
 */

/* Include files */
#include "example.h"

/* Function Definitions */
void example(double x, double y[7])
{
  static const double dv[7] = {1.0, 2.0, 2.5, 3.0, 5.0, 6.0, 7.5};
  int i;
  (void)x;
  for (i = 0; i < 7; i++) {
    y[i] = dv[i];
  }
}

/* End of code generation (example.c) */
