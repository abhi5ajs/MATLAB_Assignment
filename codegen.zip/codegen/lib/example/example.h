/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * example.h
 *
 * Code generation for function 'example'
 *
 */

#ifndef EXAMPLE_H
#define EXAMPLE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void example(double x, double y[7]);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (example.h) */
